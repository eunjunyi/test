import java.text.SimpleDateFormat;
import java.util.Date;

import com.mor.test.session.JwtSessionManager;

public class Test {
	public static void main(String[] args) {
		
		JwtSessionManager manager = new JwtSessionManager();
		for(int i=0;i<100;i++) {
			System.out.println(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date(System.currentTimeMillis() + manager.betweenMillis())));
			try {
				Thread.sleep(20000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
		
}

package com.mor.test.servletandlistener;

import javax.servlet.http.HttpServlet;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;

@Configuration
@EnableRedisRepositories
public class WebConfig {
	
	@Value("${spring.redis.host}") 
	private String redisHost; 
	
	@Value("${spring.redis.port}") 
	private int redisPort;

		
	@Bean
    public LettuceConnectionFactory redisConnectionFactory() {
		System.out.println("redisHost:"+redisHost);
		System.out.println("redisPort:"+redisPort);
		LettuceConnectionFactory lettuceConnectionFactory = new LettuceConnectionFactory(redisHost, redisPort);
		return lettuceConnectionFactory;
    }
	@Bean
    public RedisTemplate<?, ?> redisTemplate() {
        RedisTemplate<byte[], byte[]> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory());
        return redisTemplate;
    }
	
	
   @Bean	
   public ServletRegistrationBean<HttpServlet> stateServlet() {
	   ServletRegistrationBean servRegBean = new ServletRegistrationBean(new HelloStateServlet());
	   servRegBean.setServlet(new HelloStateServlet());
	   servRegBean.addUrlMappings("/state/*");
	   servRegBean.setLoadOnStartup(1);
	   return servRegBean;
   }   
} 

package com.mor.test.session;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.mor.test.redis.UserRedisRepository;
import com.mor.test.welcomelist.JwtAuthentication;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtSessionManager {
	private final Logger logger = LoggerFactory.getLogger(this.getClass().getSimpleName());
	
	private static final String SALT =  "SGSC_SALT";
	
	public static final String HEADER_AUTH = "Authorization";
	
	public enum USER_ROLE{
		ADMIN (new GrantedAuthority() {
			public String getAuthority() {return "ROLE_ADMIN";}
		}),
		USER (new GrantedAuthority() {
			public String getAuthority() {return "ROLE_USER";}
		}),
		MANAGER (new GrantedAuthority() {
			public String getAuthority() {return "ROLE_MANAGER";}
		});
		
		private final GrantedAuthority role;
		USER_ROLE(GrantedAuthority role) {
			this.role =role;
		}
		public GrantedAuthority get() {
			return this.role;
		}
		public String  toString() {return role.getAuthority();}
	}
	
	@Autowired
	UserRedisRepository userRedisRepository;
	
	//@Autowired
	//AuthenticationManager authenticationManager;
	
	
	public long betweenMillis() {
		
		int closeTime = 4;
		LocalDateTime nowtime = LocalDateTime.now(); 
		//Asia/Seoul
		int hour = nowtime.getHour(); 
		int plusDay= 0;
		if(hour >closeTime) plusDay++;
		LocalDateTime endtime =	LocalDateTime.of(nowtime.plusDays(plusDay).toLocalDate(),LocalTime.of(closeTime,0,0));
		Duration duration = Duration.between(nowtime, endtime);
		return duration.toMillis();
	}
	
	
	/**
	 * 사용자 세션 관리
	 * 추후 디비로 관리 될수  있음.
	 * String token
	 */
	
	public String login(Map userinfo) {
		
		String userId = (String)userinfo.get("user_id");
		
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
		String prejwt = request.getHeader(JwtSessionManager.HEADER_AUTH);
		System.out.println("isUsable(prejwt):"+isUsable(prejwt));
		//Bearer
		//사전로그인체크 ///
		if(prejwt!=null && isUsable(prejwt)) {
			System.out.println("이미 로그인");
			return prejwt;
		}
		//필수정보세팅.
		Map claims = new HashMap();
		claims.put("user_id", userId);
		claims.put("user_nm", userinfo.get("user_nm"));
				 
		//소멸시간 밤12시로 세팅
		String jwt = Jwts.builder()
			.setHeaderParam("typ", "JWT")
			.setHeaderParam("alg", SignatureAlgorithm.HS256)
			.setClaims(claims)
			.setSubject(userId)
			.setIssuedAt(new Date(System.currentTimeMillis()))
			.setExpiration(new Date(System.currentTimeMillis() + betweenMillis()))  // 새벽 4시, 60분 1000 * 60 * 60 
			.signWith(SignatureAlgorithm.HS256, this.generateKey())
			.compact();  
		
		SessionDto sessionDto = new SessionDto();
		sessionDto.setToken(jwt);
		sessionDto.setDeptId((String)userinfo.get("dept_cd")); //부서
		sessionDto.setDevice((String)userinfo.get("device")); //접속장비
		sessionDto.setUserNm((String)userinfo.get("user_nm")); //부서
		sessionDto.setUserId((String)userinfo.get("user_id")); //userId
		
		userRedisRepository.save(sessionDto);
		
		return jwt;
	}
	
	private byte[] generateKey(){
		byte[] key = null;
		try {
			key = SALT.getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
		}
		return key;
	}
	
	//$ redis-cli
	//> CONFIG SET protected-mode no


	//로그아웃처리.
	public void logout(String jwt) {
		logger.debug("\nlogout#############################");
		userRedisRepository.deleteById(jwt);
	}
	
	public void logout() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
		String jwt = request.getHeader(HEADER_AUTH);//"Authorization"
		logout(jwt);
	}
	
	public Claims getJwtToClaims(String jwt) {
		Jws<Claims> claims = null;
		try {
			claims = Jwts.parser()
					 .setSigningKey(SALT.getBytes("UTF-8"))
					 .parseClaimsJws(jwt);
		} catch (Throwable e) {
			e.printStackTrace();
			throw new RuntimeException(e) ;
		}
		return claims!=null?claims.getBody():null;
	}
	
	public boolean isNotUsable(String jwt) {
		return !isUsable( jwt);
	}
	
	public boolean isUsable(String jwt) {
		try{
			logger.debug("\nGLOBAL_SESSION_MAP.containsKey(jwt):"+jwt);
			
			Optional<SessionDto> userOption =  userRedisRepository.findById(jwt);
			
			if( getCliams(jwt).getExpiration().before(new Date()) || !userOption.isPresent()) {  //&& redis 에 미존재 token인 경우.
				return false;
			}
			
			//UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(jwt, "");
			//Authentication authentication = authenticationManager.authenticate(token);
			SessionDto sessionDto = userOption.get();
			JwtAuthentication authentication = new JwtAuthentication();
			authentication.setUserId(sessionDto.getUserId());
			authentication.setUserNm(sessionDto.getUsername());
			authentication.setToken(jwt);
			authentication.setDetails(sessionDto);
			
			List<GrantedAuthority> roles= new ArrayList<GrantedAuthority>();
			roles.add(USER_ROLE.ADMIN.get());
			roles.add(USER_ROLE.USER.get());
			authentication.setAuthorities(roles);
			
			SecurityContextHolder.getContext().setAuthentication(authentication);
			
			//SessionDto dto = (SessionDto)authentication.getDetails();
			//System.out.println("dto:"+dto);
			
			/*JwtParser parser = Jwts.parser().setSigningKey(this.generateKey());
			Jws<Claims> claimJws = parser.parseClaimsJws(jwt);
			Claims body = claimJws.getBody();*/
			
			return true;
		}catch (Throwable e) {
			e.printStackTrace();
			return false;
			
			/* 1) ExpiredJwtException : JWT를 생성할 때 지정한 유효기간 초과할 때.
				2) UnsupportedJwtException : 예상하는 형식과 일치하지 않는 특정 형식이나 구성의 JWT일 때
				3) MalformedJwtException : JWT가 올바르게 구성되지 않았을 때
				4) SignatureException :  JWT의 기존 서명을 확인하지 못했을 때
				5) IllegalArgumentException*/
			/*
			 * if(e.getCause() !=null) { if(e.getCause() instanceof ExpiredJwtException) {
			 * throw new
			 * BusinessException("A001","계정 권한이 유효하지 않습니다.\\n다시 로그인을 해주세요",e.toString());
			 * }else if(e.getCause() instanceof UnsupportedJwtException) { throw new
			 * BusinessException("A001","계정 권한이 유효하지 않습니다.\\n다시 로그인을 해주세요",e.toString());
			 * }else if(e.getCause() instanceof MalformedJwtException) { throw new
			 * BusinessException("A001","계정 권한이 유효하지 않습니다.\\n다시 로그인을 해주세요",e.toString());
			 * }else if(e.getCause() instanceof SignatureException) { throw new
			 * BusinessException("A001","계정 권한이 유효하지 않습니다.\\n다시 로그인을 해주세요",e.toString());
			 * }else { throw new
			 * BusinessException("A001","계정 권한이 유효하지 않습니다.\\n다시 로그인을 해주세요",e.toString()); }
			 * } throw new
			 * BusinessException("A001","계정 권한이 유효하지 않습니다.\\n다시 로그인을 해주세요",e.toString());
			 */
		}
	}
	
	public Map<String, Object> getCliam(String key) {
		Claims claims = getCliams();
		@SuppressWarnings("unchecked")
		Map<String, Object> value = (HashMap<String, Object>)claims.get(key);
		return value;
	}
	
	
	public Claims getCliams() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
		String jwt = request.getHeader(HEADER_AUTH);//"Authorization"
		return getCliams(jwt);
	}
	
	
	public Claims getCliams(String jwt) {
		Jws<Claims> claims = null;
		try {
			claims = Jwts.parser()
					 .setSigningKey(SALT.getBytes("UTF-8"))
					 .parseClaimsJws(jwt);
			
			logger.debug("before:"+claims.getBody().getExpiration().before(new Date()));
			logger.debug("after:"+claims.getBody().getExpiration().after(new Date()));
			logger.debug("===>"+new SimpleDateFormat("yyyyMMddHHmmssSSS").format(claims.getBody().getExpiration()) +" "+new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()));
		} catch (Throwable e) {
			e.printStackTrace();
			throw new RuntimeException(e) ;
		}
		return claims!=null?claims.getBody():null;
	}
	
    //유효기간 확인
    private Boolean isTokenExpired() {
        return extractExpiration().before(new Date());
    }
    
    public Date extractExpiration() {
        return extractClaim(Claims::getExpiration);
    }
    
    public <T> T extractClaim(Function<Claims, T> claimsResolver) {
        return claimsResolver.apply(getCliams());
    }
    
    public boolean isUsable() {
    	System.out.println("isUsable():"+isUsable());
    	HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
    	String prejwt = request.getHeader(JwtSessionManager.HEADER_AUTH);
    	return isUsable(prejwt);
    }

}
